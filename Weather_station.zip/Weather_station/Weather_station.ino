#include <WiFiManager.h>
#include <WiFiClientSecure.h>
#include <TFT_eSPI.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <ESP32Time.h>
#include "NotoSansBold15.h"
#include "tinyFont.h"
#include "smallFont.h"
#include "midleFont.h"
#include "bigFont.h"
#include "font18.h"

TFT_eSPI tft = TFT_eSPI();
TFT_eSprite sprite = TFT_eSprite(&tft);
TFT_eSprite errSprite = TFT_eSprite(&tft);
ESP32Time rtc(0);

int zone = 7;
String town = ""; //Your Town In Screen
String townQ = ""; //Your Town In Open Weather Map
String myAPI = ""; //Your API Open Weather Map
String units = "metric";
bool isImperial = false;
bool wasFailed = false;

const char* ntpServer = "time.google.com";
String server = "";

int ani = 100;
int wmsgWidth = 0;
unsigned long timePased = 0;
unsigned long batTimePased = 0;
int counter = 0;

String lastDescription = "n/a";

#define bck TFT_BLACK
unsigned short grays[13];

#define OUT_PIN 15
#define BTN_PIN 14
#define BAT_PIN 4
#define UNIT_PIN 0

#ifdef TFT_BL
  #define BL_PIN TFT_BL
#else
  #define BL_PIN 38
#endif

const int BRIGHT_STEP = 25;
const int BRIGHT_MIN = 10;
const int BRIGHT_MAX = 255;
int brightness = 204;

bool blinkActive = false;
unsigned long blinkStart = 0;
unsigned long lastBlinkEnd = 0;
const unsigned long BLINK_DURATION = 500;
const unsigned long BLINK_COOLDOWN = 1000;

void applyBrightness() {
  if (brightness < BRIGHT_MIN) brightness = BRIGHT_MIN;
  if (brightness > BRIGHT_MAX) brightness = BRIGHT_MAX;
  if (!blinkActive) ledcWrite(BL_PIN, brightness);
}

void triggerBlink() {
  if (blinkActive) return;
  if (lastBlinkEnd != 0 && (millis() - lastBlinkEnd < BLINK_COOLDOWN)) return;
  blinkActive = true;
  blinkStart = millis();
  ledcWrite(BL_PIN, 0);
}

void updateBlink() {
  if (blinkActive && (millis() - blinkStart >= BLINK_DURATION)) {
    blinkActive = false;
    lastBlinkEnd = millis();
    ledcWrite(BL_PIN, brightness);
  }
}

bool outState = true;
int batPct = 0;

float temperature = 0.0;
float feels = 0.0;
float humidity = 0.0;
float pressure = 0.0;
float wind = 0.0;
float gust = 0.0;
float rain = 0.0;
float clouds = 0.0;
float visibility = 0.0;

String sunriseStr = "--:--";
String sunsetStr = "--:--";
String Wmsg = "Loading...";

void buildServer() {
  server = "https://api.openweathermap.org/data/2.5/weather?q=" + townQ + "&appid=" + myAPI + "&units=" + units;
}

int readBatPct() {
  long sum = 0;
  for (int i = 0; i < 32; i++) {
    sum += analogReadMilliVolts(BAT_PIN);
    delay(2);
  }
  int raw_mV = sum / 32;
  float dienApPin = (raw_mV / 1000.0f) * 2.0f;

  if (dienApPin < 1.0f) return 0;
  if (dienApPin >= 4.15f) return 100;
  if (dienApPin <= 3.30f) return 0;

  float pct = (dienApPin - 3.30f) / (4.15f - 3.30f) * 100.0f;
  return (int)pct;
}

float convertTemp(float v) {
  return isImperial ? (v * 9.0f / 5.0f + 32.0f) : v;
}

float convertWind(float v) {
  return isImperial ? (v * 2.23694f) : v;
}

void buildWmsg() {
  Wmsg = "#Description: " + lastDescription + "  #Rain: " + String(rain, 1) + "mm" + "  #Updated: " + rtc.getTime() + "  #Battery: " + String(batPct) + "%" + "  #Thoai  ";
  wmsgWidth = errSprite.textWidth(Wmsg);
}

void updateBattery() {
  int newPct = readBatPct();
  if (newPct != batPct) {
    batPct = newPct;
    buildWmsg();
  }
}

void handleButton() {
  {
    static unsigned long pressStart = 0;
    static bool longHandled = false;
    static bool wasPressed  = false;
    bool cur = digitalRead(BTN_PIN);

    if (cur == LOW) {
      if (!wasPressed) {
        wasPressed = true;
        pressStart = millis();
        longHandled = false;
      }
      if (!longHandled && (millis() - pressStart >= 500UL)) {
        outState = !outState;
        digitalWrite(OUT_PIN, outState);
        longHandled = true;
      }
    } else {
      if (wasPressed && !longHandled) {
        if (brightness >= BRIGHT_MAX) {
          triggerBlink();
        } else {
          brightness += BRIGHT_STEP;
          applyBrightness();
        }
      }
      wasPressed = false;
      pressStart = 0;
      longHandled = false;
    }
  }

  {
    static unsigned long pressStart = 0;
    static bool longHandled = false;
    static bool wasPressed = false;
    bool cur = digitalRead(UNIT_PIN);

    if (cur == LOW) {
      if (!wasPressed) {
        wasPressed = true;
        pressStart = millis();
        longHandled = false;
      }
      if (!longHandled && (millis() - pressStart >= 500UL)) {
        isImperial = !isImperial;
        longHandled = true;
      }
    } else {
      if (wasPressed && !longHandled) {
        if (brightness <= BRIGHT_MIN) {
          triggerBlink();
        } else {
          brightness -= BRIGHT_STEP;
          applyBrightness();
        }
      }
      wasPressed = false;
      pressStart = 0;
      longHandled = false;
    }
  }
}

void setTime() {
  configTime(3600 * zone, 0, ntpServer);
  struct tm timeinfo;
  if (getLocalTime(&timeinfo)) {
    rtc.setTimeStruct(timeinfo);
  }
}

void getData() {
  WiFiClientSecure client;
  client.setInsecure();

  HTTPClient http;
  http.setTimeout(8000);
  http.begin(client, server);
  int httpResponseCode = http.GET();

  if (httpResponseCode > 0) {
    String payload = http.getString();
    Serial.println("=== server response ===");
    Serial.println(payload);

    StaticJsonDocument<2048> doc;
    DeserializationError error = deserializeJson(doc, payload);

    if (!error) {
      temperature = doc["main"]["temp"] | 0.0f;
      feels = doc["main"]["feels_like"] | 0.0f;
      humidity = doc["main"]["humidity"] | 0.0f;
      pressure = doc["main"]["pressure"] | 0.0f;
      wind = doc["wind"]["speed"] | 0.0f;
      gust = doc["wind"]["gust"] | 0.0f;
      rain = doc["rain"]["1h"] | 0.0f;
      clouds = doc["clouds"]["all"] | 0.0f;
      visibility = (doc["visibility"] | 0) / 1000.0f;

      time_t sr = doc["sys"]["sunrise"] | 0L;
      time_t ss = doc["sys"]["sunset"]  | 0L;
      struct tm tmBuf;
      char buf[6];
      if (sr > 0) {
        localtime_r(&sr, &tmBuf);
        strftime(buf, sizeof(buf), "%H:%M", &tmBuf);
        sunriseStr = String(buf);
      }
      if (ss > 0) {
        localtime_r(&ss, &tmBuf);
        strftime(buf, sizeof(buf), "%H:%M", &tmBuf);
        sunsetStr = String(buf);
      }

      lastDescription = String((const char*)(doc["weather"][0]["description"] | "n/a"));

      batPct = readBatPct();
      buildWmsg();
    } else {
      Serial.print("ERROR JSON: ");
      Serial.println(error.c_str());
    }
  } else {
    Serial.print("HTTP ERROR: ");
    Serial.println(httpResponseCode);
  }
  http.end();
}

void drawInfoBox(int x, int y, const char* label, String value) {
  sprite.fillSmoothRoundRect(x, y, 56, 36, 3, grays[9], bck);
  sprite.setTextDatum(4);
  sprite.setTextColor(grays[3], grays[9]);
  sprite.drawString(label, x + 28, y + 9);
  sprite.loadFont(font18);
  sprite.setTextColor(grays[2], grays[9]);
  sprite.drawString(value, x + 28, y + 25);
  sprite.unloadFont();
}

void draw() {
  errSprite.fillSprite(grays[9]);
  errSprite.setTextColor(grays[1], grays[9]);

  int period = wmsgWidth;
  errSprite.drawString(Wmsg, ani, 4);
  errSprite.drawString(Wmsg, ani + period, 4);

  sprite.fillSprite(TFT_BLACK);
  sprite.drawLine(138, 10, 138, 164, grays[6]);
  sprite.drawLine(100, 108, 134, 108, grays[6]);
  sprite.setTextDatum(0);

  sprite.loadFont(midleFont);
  sprite.setTextColor(grays[1], TFT_BLACK);
  sprite.drawString("WEATHER", 6, 10);
  sprite.unloadFont();

  sprite.loadFont(font18);
  sprite.setTextColor(grays[7], TFT_BLACK);
  sprite.drawString("TOWN:", 6, 110);

  sprite.setTextColor(grays[2], TFT_BLACK);
  if (isImperial) sprite.drawString("F", 14, 50);
  else sprite.drawString("C", 14, 50);

  sprite.setTextColor(grays[3], TFT_BLACK);
  sprite.drawString(town, 46, 110);

  sprite.fillCircle(8, 52, 2, grays[2]);
  sprite.unloadFont();

  sprite.loadFont(tinyFont);
  sprite.setTextColor(grays[4], TFT_BLACK);
  sprite.drawString(rtc.getTime().substring(0, 5), 6, 132);
  sprite.unloadFont();

  sprite.loadFont(font18);
  sprite.setTextColor(grays[5], TFT_BLACK);
  sprite.drawString("STATION", 84, 15);
  sprite.setTextColor(grays[7], TFT_BLACK);
  sprite.drawString("SECOND", 89, 156);
  sprite.unloadFont();

  sprite.setTextDatum(4);
  sprite.loadFont(bigFont);
  sprite.setTextColor(grays[0], TFT_BLACK);
  sprite.drawFloat(convertTemp(temperature), 1, 69, 80);
  sprite.unloadFont();

  sprite.fillRoundRect(90, 132, 42, 22, 2, grays[2]);
  sprite.loadFont(font18);
  sprite.setTextColor(TFT_BLACK, grays[2]);
  sprite.drawString(rtc.getTime().substring(6, 8), 111, 144);
  sprite.unloadFont();

  String tUnit    = isImperial ? "F" : "C";
  String windUnit = isImperial ? "mph" : "m/s";

  drawInfoBox(144, 8, "FEELS", String(convertTemp(feels), 1) + tUnit);
  drawInfoBox(204, 8, "CLOUD", String((int)clouds) + "%");
  drawInfoBox(264, 8, "VIS", String(visibility, 1) + "km");

  drawInfoBox(144, 52, "SUNRISE", sunriseStr);
  drawInfoBox(204, 52, "SUNSET", sunsetStr);
  drawInfoBox(264, 52, "GUST", String(convertWind(gust), 1) + windUnit);

  drawInfoBox(144, 96, "HUM", String((int)humidity) + "%");
  drawInfoBox(204, 96, "PRESS", String((int)pressure) + "hPa");
  drawInfoBox(264, 96, "WIND", String(convertWind(wind), 1) + windUnit);

  sprite.fillSmoothRoundRect(144, 148, 176, 17, 2, grays[9], bck);
  errSprite.pushToSprite(&sprite, 148, 150);

  sprite.setTextDatum(4);
  sprite.setTextColor(grays[4], bck);
  sprite.drawString("CURRENT WEATHER", 190, 141);
  sprite.setTextColor(grays[8], bck);
  sprite.drawString(String(counter), 312, 141);

  sprite.pushSprite(0, 0);
}

void updateData() {
  ani--;
  int period = wmsgWidth;
  if (period > 0 && ani < -period) ani += period;

  if (millis() > batTimePased + 5000UL) {
    batTimePased = millis();
    updateBattery();
  }

  if (millis() > timePased + 180000UL) {
    timePased = millis();
    counter++;
    getData();
    if (counter >= 10) {
      counter = 0;
      setTime();
    }
  }
}

void showStatus(const char* msg, uint16_t color) {
  tft.fillScreen(TFT_BLACK);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(color, TFT_BLACK);
  tft.setTextSize(1);
  tft.drawString(msg, tft.width() / 2, tft.height() / 2);
  delay(1000);
}

void setup() {
  Serial.begin(115200);
  delay(200);

  pinMode(OUT_PIN, OUTPUT);
  digitalWrite(OUT_PIN, outState);

  pinMode(BTN_PIN, INPUT_PULLUP);
  pinMode(UNIT_PIN, INPUT_PULLUP);
  pinMode(BAT_PIN, INPUT);

  analogReadResolution(12);
  analogSetPinAttenuation(BAT_PIN, ADC_11db);
  applyBrightness();

  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(MC_DATUM);
  tft.setTextSize(2);
  tft.drawString("Thoai", tft.width() / 2, tft.height() / 2);
  delay(2000);

  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextDatum(MC_DATUM);
  tft.setTextSize(1);  
  tft.drawString("CONNECTING TO WIFI", tft.width() / 2, tft.height() / 2);

  sprite.createSprite(320, 170);
  errSprite.createSprite(164, 15);

  int co = 210;
  for (int i = 0; i < 13; i++) {
    grays[i] = tft.color565(co, co, co);
    co -= 20;
  }

  buildServer();
  WiFiManager wifiManager;
  wifiManager.setConfigPortalTimeout(0);
  wifiManager.setConnectTimeout(10);
  wifiManager.setAPCallback([](WiFiManager *mgr) {
    if (!wasFailed) {
      showStatus("NO WIFI CONFIG", TFT_YELLOW);
    }
  });

  bool needAP = true;

  if (wifiManager.getWiFiIsSaved()) {
    WiFi.mode(WIFI_STA);
    WiFi.begin();

    unsigned long start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 10000UL) {
      delay(250);
    }

    if (WiFi.status() == WL_CONNECTED) {
      needAP = false;
    } else {
      WiFi.disconnect(true);
      showStatus("CONNECTION FAILED", TFT_RED);
      wasFailed = true;
    }
  }

  if (needAP) {
    wifiManager.autoConnect("Weather Station", "password");
  }

  showStatus("CONNECTION SUCCESSFUL", TFT_GREEN);
  setTime();
  getData();
  timePased = millis();
  batTimePased = millis();
}

void loop() {
  handleButton();
  updateBlink();
  updateData();
  draw();
  delay(20);
}